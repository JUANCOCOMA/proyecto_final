-- Script mínimo PostgreSQL para SophyFarm
-- Módulo: Cotizaciones y Pedidos

CREATE TABLE condicion_pago (
  id                integer PRIMARY KEY,
  dscrpcion_cndcion varchar(100) NOT NULL,
  dias              integer NOT NULL
);

CREATE TABLE cliente (
  id             integer PRIMARY KEY,
  nit_clnte      varchar(12) NOT NULL,
  nmbre_clnte    varchar(40) NOT NULL,
  drccion_clnte  varchar(50),
  crreo_clnte    varchar(50),
  tlfno_clnte    varchar(20),
  estdo_clnte    varchar(1) NOT NULL
);

CREATE TABLE elemento (
  id                integer PRIMARY KEY,
  sku_elemnto       varchar(20) NOT NULL,
  nmbre_elemnto     varchar(40) NOT NULL,
  dscrpcion_elemnto varchar(60) NOT NULL,
  exstncia_elemnto  integer,
  precio_venta_ac   integer
);

CREATE TABLE cotizacion (
  id            integer PRIMARY KEY,
  id_cliente    integer NOT NULL,
  fcha_ctzcion  timestamp NOT NULL,
  vldez_ctzcion integer NOT NULL,
  vlor_nto      integer,
  estdo_ctzcion varchar(1) NOT NULL,
  CONSTRAINT fk_cot_cliente
    FOREIGN KEY (id_cliente) REFERENCES cliente(id)
);

CREATE TABLE cotizacion_detalle (
  id              integer PRIMARY KEY,
  id_ctzcion      integer NOT NULL,
  id_elemnto      integer NOT NULL,
  cntdad_elemnto  integer NOT NULL,
  prcio_untrio    integer NOT NULL,
  vlr_dscto       integer,
  vlr_impsto      integer,
  CONSTRAINT fk_ctz_det_cot
    FOREIGN KEY (id_ctzcion) REFERENCES cotizacion(id),
  CONSTRAINT fk_ctz_det_elem
    FOREIGN KEY (id_elemnto) REFERENCES elemento(id)
);

CREATE TABLE pedido (
  id               integer PRIMARY KEY,
  id_cliente       integer NOT NULL,
  id_cndcion_pago  integer NOT NULL,
  fcha_pdido       timestamp NOT NULL,
  vlor_nto         integer,
  estdo_pdido      varchar(1) NOT NULL,
  CONSTRAINT fk_ped_cliente
    FOREIGN KEY (id_cliente) REFERENCES cliente(id),
  CONSTRAINT fk_ped_cond
    FOREIGN KEY (id_cndcion_pago) REFERENCES condicion_pago(id)
);

CREATE TABLE pedido_detalle (
  id              integer PRIMARY KEY,
  id_pdido        integer NOT NULL,
  id_elemnto      integer NOT NULL,
  cntdad_elemnto  integer NOT NULL,
  prcio_untrio    integer NOT NULL,
  vlr_dscto       integer,
  vlr_impsto      integer,
  CONSTRAINT fk_ped_det_ped
    FOREIGN KEY (id_pdido) REFERENCES pedido(id),
  CONSTRAINT fk_ped_det_elem
    FOREIGN KEY (id_elemnto) REFERENCES elemento(id)
);
