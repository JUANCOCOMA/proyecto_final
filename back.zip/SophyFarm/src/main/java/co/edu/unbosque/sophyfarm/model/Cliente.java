package co.edu.unbosque.sophyfarm.model;

import jakarta.persistence.*;

@Entity
@Table(name = "cliente")

/**
 * Entidad que representa un cliente dentro del sistema SophyFarm.
 * Contiene información básica como identificación, nombre, contacto
 * y estado del cliente, necesaria para registrar cotizaciones y pedidos.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public class Cliente {

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "nit_clnte", length = 12, nullable = false)
    private String nit;

    @Column(name = "nmbre_clnte", length = 40, nullable = false)
    private String nombre;

    @Column(name = "drccion_clnte", length = 50)
    private String direccion;

    @Column(name = "crreo_clnte", length = 50)
    private String correo;

    @Column(name = "tlfno_clnte", length = 20)
    private String telefono;

    @Column(name = "estdo_clnte", length = 1, nullable = false)
    private String estado;

    public Cliente() {}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

    
}
