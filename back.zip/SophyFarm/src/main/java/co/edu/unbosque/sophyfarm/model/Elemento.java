package co.edu.unbosque.sophyfarm.model;

import jakarta.persistence.*;

@Entity
@Table(name = "elemento")

/**
 * Entidad que representa un elemento o producto disponible en SophyFarm
 * para ser incluido en cotizaciones y pedidos. Contiene información como
 * SKU, nombre, descripción, existencia y precio unitario.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public class Elemento {

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "sku_elemnto", length = 20, nullable = false)
    private String sku;

    @Column(name = "nmbre_elemnto", length = 40, nullable = false)
    private String nombre;

    @Column(name = "dscrpcion_elemnto", length = 60, nullable = false)
    private String descripcion;

    @Column(name = "exstncia_elemnto")
    private Integer existencia;

    @Column(name = "precio_venta_ac")
    private Integer precioActual;

    public Elemento() {}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Integer getExistencia() {
		return existencia;
	}

	public void setExistencia(Integer existencia) {
		this.existencia = existencia;
	}

	public Integer getPrecioActual() {
		return precioActual;
	}

	public void setPrecioActual(Integer precioActual) {
		this.precioActual = precioActual;
	}

    
}
