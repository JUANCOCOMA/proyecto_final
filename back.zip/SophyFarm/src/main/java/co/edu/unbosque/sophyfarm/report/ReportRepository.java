package co.edu.unbosque.sophyfarm.report;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ReportRepository extends CrudRepository<Object, Long> {

    @Query(value = """
            SELECT 
                TO_CHAR(c.fecha, 'YYYY-MM') AS mes,
                COUNT(*) AS total
            FROM cotizacion c
            GROUP BY TO_CHAR(c.fecha, 'YYYY-MM')
            ORDER BY mes
            """, nativeQuery = true)
    List<Object[]> cotizacionesPorMes();
    
    @Query(value = """
            SELECT 
                e.nombre AS elemento,
                COUNT(cd.elemento_id) AS veces_cotizado
            FROM cotizacion_detalle cd
            JOIN elemento e ON cd.elemento_id = e.id
            GROUP BY e.nombre
            ORDER BY veces_cotizado DESC
            LIMIT 5
            """, nativeQuery = true)
    List<Object[]> topElementos();
    
    @Query(value = """
            SELECT 
                c.nombre AS cliente,
                COUNT(p.id) AS total_pedidos
            FROM pedido p
            JOIN cliente c ON p.cliente_id = c.id
            GROUP BY c.nombre
            ORDER BY total_pedidos DESC
            """, nativeQuery = true)
    List<Object[]> pedidosPorCliente();


}
