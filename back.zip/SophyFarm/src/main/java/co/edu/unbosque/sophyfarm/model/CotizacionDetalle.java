package co.edu.unbosque.sophyfarm.model;

import jakarta.persistence.*;

@Entity
@Table(name = "cotizacion_detalle")

/**
 * Entidad que modela el detalle de una cotización, especificando
 * cada elemento incluido, la cantidad solicitada y los valores
 * de precio unitario, impuestos y descuentos aplicados.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public class CotizacionDetalle {

    @Id
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "id_ctzcion", nullable = false)
    private Cotizacion cotizacion;

    @ManyToOne
    @JoinColumn(name = "id_elemnto", nullable = false)
    private Elemento elemento;

    @Column(name = "cntdad_elemnto", nullable = false)
    private Integer cantidad;

    @Column(name = "prcio_untrio", nullable = false)
    private Integer precioUnitario;

    @Column(name = "vlr_dscto")
    private Integer descuento;

    @Column(name = "vlr_impsto")
    private Integer impuesto;

    public CotizacionDetalle() {}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Cotizacion getCotizacion() {
		return cotizacion;
	}

	public void setCotizacion(Cotizacion cotizacion) {
		this.cotizacion = cotizacion;
	}

	public Elemento getElemento() {
		return elemento;
	}

	public void setElemento(Elemento elemento) {
		this.elemento = elemento;
	}

	public Integer getCantidad() {
		return cantidad;
	}

	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}

	public Integer getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(Integer precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public Integer getDescuento() {
		return descuento;
	}

	public void setDescuento(Integer descuento) {
		this.descuento = descuento;
	}

	public Integer getImpuesto() {
		return impuesto;
	}

	public void setImpuesto(Integer impuesto) {
		this.impuesto = impuesto;
	}

    
}
