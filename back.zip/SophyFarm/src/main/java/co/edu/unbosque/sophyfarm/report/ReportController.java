package co.edu.unbosque.sophyfarm.report;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/reportes")
@CrossOrigin("*")
public class ReportController {

    private final ReportService service;

    public ReportController(ReportService service) {
        this.service = service;
    }

    @GetMapping("/cotizaciones-por-mes")
    public List<Map<String, Object>> cotizacionesPorMes() {
        return service.cotizacionesPorMes();
    }
    
    @GetMapping("/top-elementos")
    public List<Map<String, Object>> topElementos() {
        return service.topElementos();
    }
    
    @GetMapping("/pedidos-por-cliente")
    public List<Map<String, Object>> pedidosPorCliente() {
        return service.pedidosPorCliente();
    }


}
