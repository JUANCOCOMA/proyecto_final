package co.edu.unbosque.sophyfarm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import io.swagger.v3.oas.annotations.servers.Server;

/**
 * Clase principal del microservicio SophyFarm.
 *
 * <p>
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos para una droguería.
 * </p>
 *
 * <p>
 * Autores: Grupo 8 – Ingeniería de Sistemas.<br/>
 * Universidad El Bosque.
 * </p>
 */
@OpenAPIDefinition(
    info = @Info(
        title = "API SophyFarm - Cotizaciones y Pedidos",
        version = "1.0.0",
        description = "Microservicio REST para gestionar cotizaciones y pedidos de la droguería SophyFarm.",
        contact = @Contact(
            name = "Grupo 8",
            email = "grupo8@sophyfarm.com"
        ),
        license = @License(
            name = "Uso académico",
            url = "https://www.unbosque.edu.co"
        )
    ),
    servers = {
        @Server(
            url = "http://localhost:8080",
            description = "Servidor local de desarrollo"
        )
    }
)
@SpringBootApplication
public class SophyfarmCotizacionesPedidosApplication {

    public static void main(String[] args) {
        SpringApplication.run(SophyfarmCotizacionesPedidosApplication.class, args);
    }
}
