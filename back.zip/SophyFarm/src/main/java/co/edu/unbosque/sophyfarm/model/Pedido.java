package co.edu.unbosque.sophyfarm.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "pedido")

/**
 * Entidad que representa un pedido registrado en SophyFarm.
 * Contiene información del cliente, condición de pago, fecha del pedido,
 * valor neto y estado. Cada pedido contiene múltiples elementos detallados
 * en PedidoDetalle.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public class Pedido {

    @Id
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "id_cliente", nullable = false)
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "id_cndcion_pago", nullable = false)
    private CondicionPago condicionPago;

    @Column(name = "fcha_pdido", nullable = false)
    private LocalDateTime fechaPedido;

    @Column(name = "vlor_nto")
    private Integer valorNeto;

    @Column(name = "estdo_pdido", length = 1, nullable = false)
    private String estado;

    public Pedido() {}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public CondicionPago getCondicionPago() {
		return condicionPago;
	}

	public void setCondicionPago(CondicionPago condicionPago) {
		this.condicionPago = condicionPago;
	}

	public LocalDateTime getFechaPedido() {
		return fechaPedido;
	}

	public void setFechaPedido(LocalDateTime fechaPedido) {
		this.fechaPedido = fechaPedido;
	}

	public Integer getValorNeto() {
		return valorNeto;
	}

	public void setValorNeto(Integer valorNeto) {
		this.valorNeto = valorNeto;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

    
}
