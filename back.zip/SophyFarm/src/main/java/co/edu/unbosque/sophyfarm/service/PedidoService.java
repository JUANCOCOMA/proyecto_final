package co.edu.unbosque.sophyfarm.service;

import co.edu.unbosque.sophyfarm.model.Pedido;
import co.edu.unbosque.sophyfarm.repository.PedidoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
/**
 * Servicio de aplicación para la gestión de pedidos en SophyFarm.
 * Implementa la lógica de negocio necesaria para registrar, consultar
 * y administrar pedidos a través del
 * {@link co.edu.unbosque.sophyfarm.repository.PedidoRepository}.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public class PedidoService {

    private final PedidoRepository repository;

    public PedidoService(PedidoRepository repository) {
        this.repository = repository;
    }

    public List<Pedido> listarTodos() {
        return repository.findAll();
    }

    public Pedido buscarPorId(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado con id " + id));
    }

    public Pedido crear(Pedido pedido) {
        return repository.save(pedido);
    }

    public Pedido actualizar(Integer id, Pedido pedido) {
        Pedido existente = buscarPorId(id);
        existente.setCliente(pedido.getCliente());
        existente.setCondicionPago(pedido.getCondicionPago());
        existente.setFechaPedido(pedido.getFechaPedido());
        existente.setValorNeto(pedido.getValorNeto());
        existente.setEstado(pedido.getEstado());
        return repository.save(existente);
    }

    public void eliminar(Integer id) {
        repository.deleteById(id);
    }
}
