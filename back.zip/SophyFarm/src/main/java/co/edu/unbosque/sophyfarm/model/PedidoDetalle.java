package co.edu.unbosque.sophyfarm.model;

import jakarta.persistence.*;

@Entity
@Table(name = "pedido_detalle")

/**
 * Entidad que define el detalle de un pedido, indicando los elementos
 * adquiridos, la cantidad, precios unitarios y cálculos relacionados
 * como descuentos e impuestos.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public class PedidoDetalle {

    @Id
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "id_pdido", nullable = false)
    private Pedido pedido;

    @ManyToOne
    @JoinColumn(name = "id_elemnto", nullable = false)
    private Elemento elemento;

    @Column(name = "cntdad_elemnto", nullable = false)
    private Integer cantidad;

    @Column(name = "prcio_untrio", nullable = false)
    private Integer precioUnitario;

    @Column(name = "vlr_dscto")
    private Integer descuento;

    @Column(name = "vlr_impsto")
    private Integer impuesto;

    public PedidoDetalle() {}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

	public Elemento getElemento() {
		return elemento;
	}

	public void setElemento(Elemento elemento) {
		this.elemento = elemento;
	}

	public Integer getCantidad() {
		return cantidad;
	}

	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}

	public Integer getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(Integer precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public Integer getDescuento() {
		return descuento;
	}

	public void setDescuento(Integer descuento) {
		this.descuento = descuento;
	}

	public Integer getImpuesto() {
		return impuesto;
	}

	public void setImpuesto(Integer impuesto) {
		this.impuesto = impuesto;
	}

}
