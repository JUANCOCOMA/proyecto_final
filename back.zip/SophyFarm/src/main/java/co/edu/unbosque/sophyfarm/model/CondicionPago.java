package co.edu.unbosque.sophyfarm.model;

import jakarta.persistence.*;

@Entity
@Table(name = "condicion_pago")

/**
 * Entidad que modela la condición de pago asociada a un pedido.
 * Define el tipo de pago y la cantidad de días de plazo que tiene
 * el cliente para realizarlo.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public class CondicionPago {

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "dscrpcion_cndcion", length = 100, nullable = false)
    private String descripcion;

    @Column(name = "dias", nullable = false)
    private Integer dias;

    public CondicionPago() {}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Integer getDias() {
		return dias;
	}

	public void setDias(Integer dias) {
		this.dias = dias;
	}

    
}
