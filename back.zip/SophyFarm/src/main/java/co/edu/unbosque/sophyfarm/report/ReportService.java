package co.edu.unbosque.sophyfarm.report;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ReportService {

    private final ReportRepository repo;

    public ReportService(ReportRepository repo) {
        this.repo = repo;
    }

    public List<Map<String, Object>> cotizacionesPorMes() {
        return repo.cotizacionesPorMes()
            .stream()
            .map(r -> Map.of(
                    "mes", r[0],
                    "total", r[1]
            ))
            .toList();
    }
    
    public List<Map<String, Object>> topElementos() {
        return repo.topElementos()
            .stream()
            .map(r -> Map.of(
                    "elemento", r[0],
                    "vecesCotizado", r[1]
            ))
            .toList();
    }
    
    public List<Map<String, Object>> pedidosPorCliente() {
        return repo.pedidosPorCliente()
            .stream()
            .map(r -> Map.of(
                    "cliente", r[0],
                    "totalPedidos", r[1]
            ))
            .toList();
    }


}
