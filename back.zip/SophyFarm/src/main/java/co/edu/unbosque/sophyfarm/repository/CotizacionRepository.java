package co.edu.unbosque.sophyfarm.repository;

import co.edu.unbosque.sophyfarm.model.Cotizacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
/**
 * Repositorio JPA para la entidad {@link co.edu.unbosque.sophyfarm.model.Cotizacion}.
 * Permite realizar operaciones CRUD y consultas sobre las cotizaciones
 * almacenadas en la base de datos de SophyFarm.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public interface CotizacionRepository extends JpaRepository<Cotizacion, Integer> {
}
