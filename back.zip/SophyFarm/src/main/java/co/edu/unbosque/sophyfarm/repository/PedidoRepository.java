package co.edu.unbosque.sophyfarm.repository;

import co.edu.unbosque.sophyfarm.model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
/**
 * Repositorio JPA para la entidad {@link co.edu.unbosque.sophyfarm.model.Pedido}.
 * Provee acceso a las operaciones CRUD y consultas sobre los pedidos
 * registrados en la base de datos de SophyFarm.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public interface PedidoRepository extends JpaRepository<Pedido, Integer> {
}
