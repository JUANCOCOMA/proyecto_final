package co.edu.unbosque.sophyfarm.service;

import co.edu.unbosque.sophyfarm.model.Cotizacion;
import co.edu.unbosque.sophyfarm.repository.CotizacionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
/**
 * Servicio de aplicación encargado de gestionar la lógica de negocio
 * relacionada con las cotizaciones de SophyFarm. Centraliza las operaciones
 * de creación, consulta y actualización de cotizaciones utilizando
 * el {@link co.edu.unbosque.sophyfarm.repository.CotizacionRepository}.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public class CotizacionService {

    private final CotizacionRepository repository;

    public CotizacionService(CotizacionRepository repository) {
        this.repository = repository;
    }

    public List<Cotizacion> listarTodas() {
        return repository.findAll();
    }

    public Cotizacion buscarPorId(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cotización no encontrada con id " + id));
    }

    public Cotizacion crear(Cotizacion cotizacion) {
        // Si en la BD el ID es autoincrement, aquí normalmente se deja null
        return repository.save(cotizacion);
    }

    public Cotizacion actualizar(Integer id, Cotizacion cotizacion) {
        Cotizacion existente = buscarPorId(id);
        // copiamos campos que se permiten actualizar
        existente.setCliente(cotizacion.getCliente());
        existente.setFecha(cotizacion.getFecha());
        existente.setValidezDias(cotizacion.getValidezDias());
        existente.setValorNeto(cotizacion.getValorNeto());
        existente.setEstado(cotizacion.getEstado());
        return repository.save(existente);
    }

    public void eliminar(Integer id) {
        repository.deleteById(id);
    }
}
