package co.edu.unbosque.sophyfarm.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "cotizacion")

/**
 * Entidad que representa una cotización realizada en SophyFarm.
 * Incluye datos del cliente, fecha de creación, fecha de validez
 * y valor total cotizado. Se relaciona con CotizacionDetalle para
 * registrar los elementos incluidos.
 *
 * Proyecto: SophyFarm – Módulo de Cotizaciones y Pedidos
 * Autores: Grupo 8 – Universidad El Bosque
 * Año: 2025
 */

public class Cotizacion {

    @Id
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "id_cliente", nullable = false)
    private Cliente cliente;

    @Column(name = "fcha_ctzcion", nullable = false)
    private LocalDateTime fecha;

    @Column(name = "vldez_ctzcion", nullable = false)
    private Integer validezDias;

    @Column(name = "vlor_nto")
    private Integer valorNeto;

    @Column(name = "estdo_ctzcion", length = 1, nullable = false)
    private String estado;

    public Cotizacion() {}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public LocalDateTime getFecha() {
		return fecha;
	}

	public void setFecha(LocalDateTime fecha) {
		this.fecha = fecha;
	}

	public Integer getValidezDias() {
		return validezDias;
	}

	public void setValidezDias(Integer validezDias) {
		this.validezDias = validezDias;
	}

	public Integer getValorNeto() {
		return valorNeto;
	}

	public void setValorNeto(Integer valorNeto) {
		this.valorNeto = valorNeto;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

    
}
