package co.edu.unbosque.sophyfarm.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * Manejador global de excepciones para controladores REST.
 * <p>
 * Esta clase utiliza la anotación {@link ControllerAdvice} para interceptar
 * las excepciones no manejadas en toda la aplicación y responder con una estructura HTTP adecuada.
 * </p>
 *
 * <p>
 * Actualmente captura cualquier excepción genérica {@link Exception} y responde con un error 500 (INTERNAL_SERVER_ERROR),
 * enviando el mensaje de la excepción en el cuerpo de la respuesta.
 * </p>
 *
 * <p>
 * Esta clase es clave para mejorar la robustez y la experiencia del consumidor de la API,
 * evitando fugas de detalles técnicos y facilitando el manejo centralizado de errores.
 * </p>
 * 
 * @author Juan David Galindo
 * @version 1.0
 * @since 2025-11
 */
@ControllerAdvice
public class RestExceptionHandler {

    /**
     * Maneja excepciones genéricas lanzadas en los controladores REST.
     *
     * @param ex excepción capturada.
     * @return respuesta HTTP con código 500 y el mensaje de error como cuerpo.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(Exception ex) {
        return ResponseEntity
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(ex.getMessage());
    }
}
