# SophyFarm – Microservicio de Cotizaciones y Pedidos

Microservicio backend desarrollado en **Spring Boot** para gestionar las cotizaciones y pedidos de la droguería **SophyFarm**. El servicio expone una API REST, se conecta a una base de datos **PostgreSQL** y se despliega mediante **Docker Compose**.

---

## 1. Objetivo del microservicio

Implementar el módulo de **cotizaciones y pedidos** de SophyFarm como un **microservicio independiente**, con:

- Su propia base de datos.
- API REST documentada.
- Despliegue en contenedores Docker.
- Integración posterior con un frontend separado.

---

## 2. Arquitectura

- **Arquitectura**: Microservicio REST
- **Backend**: Spring Boot 3 / Java 21
- **ORM**: Spring Data JPA / Hibernate
- **Base de datos**: PostgreSQL 15 (contenedor Docker `sophyfarm_db`)
- **Despliegue**: Docker + Docker Compose
- **Documentación API**: OpenAPI/Swagger (`@OpenAPIDefinition`)

Diagrama lógico (texto):

- `sophyfarm_ms_cot_ped`  
  ↔ se comunica vía JDBC con  
- `sophyfarm_db` (PostgreSQL, BD `sophyfarm`)

---

## 3. Modelo de dominio (tablas principales)

El microservicio trabaja sobre las siguientes entidades/tablas:

- `cliente` → información de clientes.
- `condicion_pago` → condiciones de pago asociadas a pedidos.
- `elemento` → productos/insumos que se pueden cotizar o pedir.
- `cotizacion` → encabezado de cotizaciones.
- `cotizacion_detalle` → detalle de cada elemento de una cotización.
- `pedido` → encabezado de pedidos.
- `pedido_detalle` → detalle de elementos en un pedido.

Las entidades JPA están en el paquete:

`co.edu.unbosque.sophyfarm.model`

---

## 4. Endpoints principales

### Cotizaciones

- `GET /cotizaciones`  
  Lista todas las cotizaciones registradas.

- `GET /cotizaciones/{id}`  
  Consulta una cotización por su identificador.

- `POST /cotizaciones`  
  Crea una nueva cotización a partir de los datos enviados en el cuerpo de la petición.

### Pedidos

- `GET /pedidos`  
  Lista todos los pedidos registrados.

- `GET /pedidos/{id}`  
  Consulta un pedido por su identificador.

- `POST /pedidos`  
  Registra un nuevo pedido.

*(Los endpoints exactos pueden ajustarse según la implementación final del controller.)*

---

## 5. Ejecución con Docker

### Requisitos previos

- Docker y Docker Compose instalados.
- Java 21 (opcional si se corre desde IDE).
- Maven (opcional si se construye manualmente el JAR).

### Archivos relevantes

- `docker-compose.yml`  
  Orquesta los contenedores del backend y de la base de datos.
- Carpeta `db-init`  
  Contiene el script `01_sophyfarm.sql` que crea las tablas necesarias en la BD.

### Pasos para levantar el entorno completo

Desde la carpeta raíz del proyecto `SophyFarm`:

1. Construir imagen y levantar contenedores:

   ```bash
   docker compose up --build
Verificar:

PostgreSQL se levanta en el contenedor sophyfarm_db usando la BD sophyfarm.

El microservicio se levanta en el contenedor sophyfarm_ms_cot_ped en el puerto 8080.

Probar el microservicio (ejemplos con curl):

curl http://localhost:8080/cotizaciones
curl http://localhost:8080/pedidos


Si Spring Security está habilitado por defecto, se deben usar credenciales básicas (user + password generado en logs) o la configuración definida por el grupo.